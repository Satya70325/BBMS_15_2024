﻿using BBMS.Data.IRepository;
using BBMS.Models;

namespace BBMS.Data.Repository
{
    public class BloodGroupTypeRepository : IBloodGroupType
    {
        private readonly BBMSDataContext _context;
        public BloodGroupTypeRepository(BBMSDataContext context)
        {
            _context = context;
        }
        public BloodGroupTypeResponse GetAllBloodGroupTypes()
        {
            BloodGroupTypeResponse BloodGroupTypersp = new BloodGroupTypeResponse();
            try
            {
                List<BloodGroupType> GetAllGroupTypes = _context.BloodGroupTypes.Where(s => !s.IsDeleted).ToList();

                if (GetAllGroupTypes.Any())
                {
                    List<BloodGroupType> response = GetAllGroupTypes.Select(s => new BloodGroupType()
                    {
                        Id = s.Id,
                        GroupName = s.GroupName,
                        BloodUnits = s.BloodUnits
                    }).ToList();
                    BloodGroupTypersp._bloodGroupTypes = response;
                }
                BloodGroupTypersp.Status = "Success";
                BloodGroupTypersp.Msg = "Success";
                return BloodGroupTypersp;
            }
            catch (Exception)
            {

                BloodGroupTypersp.Status = "Fail";
                BloodGroupTypersp.Msg = "Fail";
                return BloodGroupTypersp;
            }
        }

        public BloodGroupTypeResponse GetBloodGroupType(int id)
        {
            BloodGroupTypeResponse BloodGroupTypersp = new BloodGroupTypeResponse();
            try
            {
                BloodGroupType? GetData = _context.BloodGroupTypes.Where(s => s.Id == id).AsQueryable().FirstOrDefault();

                if (GetData != null)
                {
                    BloodGroupTypersp._bloodGroupType = GetData;
                }
                BloodGroupTypersp.Status = "Success";
                BloodGroupTypersp.Msg = "Success";
                return BloodGroupTypersp;
            }
            catch (Exception)
            {
                BloodGroupTypersp.Status = "Fail";
                BloodGroupTypersp.Msg = "Fail";
                return BloodGroupTypersp;
            }
        }
        public BloodGroupTypeResponse AddBloodGroupType(BloodGroupType _bloodGroupType)
        {
            BloodGroupTypeResponse BloodGroupTypersp = new BloodGroupTypeResponse();
            try
            {
                var AddBGType = _context.BloodGroupTypes.Add(_bloodGroupType);
                _context.SaveChanges();
                BloodGroupTypersp.Status = "Success";
                BloodGroupTypersp.Msg = "Success";
                BloodGroupTypersp._bloodGroupType = AddBGType.Entity;
                return BloodGroupTypersp;
            }
            catch (Exception)
            {
                BloodGroupTypersp.Status = "Fail";
                BloodGroupTypersp.Msg = "Fail";
                return BloodGroupTypersp;
            }
        }
        public BloodGroupTypeResponse UpdateBloodGroupType(BloodGroupType _bloodGroupType)
        {
            BloodGroupTypeResponse BloodGroupTypersp = new BloodGroupTypeResponse();
            try
            {
                BloodGroupType? UpdateData = _context.BloodGroupTypes.Where(s => s.Id == _bloodGroupType.Id).AsQueryable().FirstOrDefault();
                if (UpdateData != null)
                {
                    UpdateData.GroupName = _bloodGroupType.GroupName;
                    UpdateData.BloodUnits = _bloodGroupType.BloodUnits;
                    UpdateData.IsDeleted = _bloodGroupType.IsDeleted;
                    UpdateData.CreatedBy = _bloodGroupType.CreatedBy;
                    UpdateData.ModifiedBy = _bloodGroupType.ModifiedBy;
                    UpdateData.CreatedOn = _bloodGroupType.CreatedOn;
                    UpdateData.ModifiedOn = _bloodGroupType.ModifiedOn;
                    UpdateData.OrderBy = _bloodGroupType.OrderBy;
                    _context.SaveChanges();
                }

                BloodGroupTypersp.Status = "Success";
                BloodGroupTypersp.Msg = "Success";
                BloodGroupTypersp._bloodGroupType = UpdateData;
                return BloodGroupTypersp;
            }
            catch (Exception)
            {
                BloodGroupTypersp.Status = "Fail";
                BloodGroupTypersp.Msg = "Fail";
                return BloodGroupTypersp;
            }
        }

        public BloodGroupTypeResponse DeleteBloodGroupType(BloodGroupType _bloodGroupType)
        {
            BloodGroupTypeResponse BloodGroupTypersp = new BloodGroupTypeResponse();
            try
            {
                BloodGroupType? DeleteData = _context.BloodGroupTypes.Where(s => s.Id == _bloodGroupType.Id).AsQueryable().FirstOrDefault();
                if (DeleteData != null)
                {
                    DeleteData.IsDeleted = true;
                    _context.SaveChanges();

                    BloodGroupTypersp.Status = "Success";
                    BloodGroupTypersp.Msg = "Success";
                    BloodGroupTypersp._bloodGroupType = DeleteData;
                    return BloodGroupTypersp;
                }
                else
                {

                    BloodGroupTypersp.Status = "Success";
                    BloodGroupTypersp.Msg = "Data Not Found";
                    BloodGroupTypersp._bloodGroupType = DeleteData;
                    return BloodGroupTypersp;
                }

            }
            catch (Exception)
            {

                BloodGroupTypersp.Status = "Fail";
                BloodGroupTypersp.Msg = "Fail";
                return BloodGroupTypersp;
            }
        }
                          
    }
}
