﻿using BBMS.Login;
using BBMS.Models;

namespace BBMS.Data.IRepository
{
    public interface IUserManagement
    {
        /// <summary>
        /// User Management Mechanism
        /// </summary>
        /// <returns></returns>
        UserManagementResponse GetAllUserManagements();
        UserManagementResponse GetUserManagement(int id);
        UserManagementResponse AddUserManagement(UserManagement _userManagement);
        UserManagementResponse UpdateUserManagement(UserManagement _userManagement);
        UserManagementResponse DeleteUserManagement(UserManagement _userManagement);

        /// <summary>
        /// Login Mechanism
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        LoginReponse GetUserLogin(LoginVM Input);
    }
}
