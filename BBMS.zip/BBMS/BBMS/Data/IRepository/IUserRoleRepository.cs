﻿using BBMS.Models;

namespace BBMS.Data.IRepository
{
    public interface IUserRoleRepository
    {
        UserRoleResponse GetAllUserRole();
        UserRoleResponse GetUserRole(int id);
        UserRoleResponse AddUserRole(UserRole _userRoles);
        UserRoleResponse UpdateUserRole(UserRole _userRoles);
        UserRoleResponse DeleteUserRole(UserRole _userRoles);
    }
}
