﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBMS.Migrations
{
    public partial class V2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "UserManagementRowId",
                table: "BloodOrders",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "BloodGroupTypeRowId",
                table: "BloodOrders",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "UserManagementRowId",
                table: "BloodDonations",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "BloodGroupTypeRowId",
                table: "BloodDonations",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9452), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9453), "c50d64ad-09d8-4087-8bb4-9a2ae0b463ed" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9457), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9457), "404a6e66-a8e3-4f4a-bff1-99dcb8a48563" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9475), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9476), "eac8fc3f-f192-469d-8ecb-a2b6797a6354" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9479), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9479), "83866478-ea7b-4be6-a1b3-93c11dc79113" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 5L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9482), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9482), "02826cf0-9593-42c9-a223-bf567537769f" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 6L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9485), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9485), "44b02784-92c1-4168-a41e-3799449fa550" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 7L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9488), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9488), "c98687f1-9adc-4de9-af60-1321c8c511cb" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 8L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9491), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9491), "d680ace2-3492-46d9-afa6-6e5b7a8ce586" });

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9429), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9429), "c11156d0-514e-410d-ad53-4656a1f01116" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9295), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9306), "25e219d8-a886-48f3-a4a3-983fc3a0914f" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9312), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9312), "a11dbe47-7579-4f9b-9593-2e7a6ae364ab" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9316), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9316), "aa4dffe3-c1d5-4502-82bc-9a7a44394943" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9319), new DateTime(2024, 5, 13, 11, 49, 25, 918, DateTimeKind.Local).AddTicks(9319), "10d06c35-a193-45bc-be84-346a7f3a7c26" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "UserManagementRowId",
                table: "BloodOrders",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BloodGroupTypeRowId",
                table: "BloodOrders",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "UserManagementRowId",
                table: "BloodDonations",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "BloodGroupTypeRowId",
                table: "BloodDonations",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7323), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7324), "f2672e36-c1c3-4994-8652-cec737d058ef" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7329), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7330), "82aaec17-c59c-42b2-ac36-742624f11a20" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7334), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7334), "f65a95cc-0367-4e22-b1c4-357a71e5c984" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7338), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7338), "c6c29c93-ae06-4492-b8c0-203475664905" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 5L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7342), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7342), "c57d194c-099a-4c5c-a36e-e684d31964d4" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 6L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7346), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7347), "eb2684f2-fdda-4eeb-be76-7ff2ada61a64" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 7L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7351), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7352), "3fa699df-c3af-43a2-b8d3-0333f634ff55" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 8L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7361), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7361), "0f8a4551-d0d3-44c3-b265-8c726cb20e1f" });

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7288), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7289), "a38254bd-c35a-4108-b01a-cb29a192a16e" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7093), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7104), "4ec0181e-815b-4e95-84a4-2d86dd84aad9" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7110), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7111), "47da6a10-9a42-468a-99f8-122542cf803f" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7115), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7116), "ff1fcc9a-7dd5-4d41-9534-953b950d090c" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7120), new DateTime(2024, 5, 10, 11, 55, 7, 6, DateTimeKind.Local).AddTicks(7120), "d98431dc-0970-4693-a948-d67254e66b61" });
        }
    }
}
