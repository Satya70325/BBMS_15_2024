﻿using BBMS.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BBMS.Login
{
    public class LoginVM
    {

        [Required]
        public string? UserName { get; set; }
        [Required]
        public string? Password { get; set; }
        [Required]
        public long? RoleId { get; set; }
        [ForeignKey("RoleId")]
        public UserRole? UserRoles { get; set; }
    }
}
