﻿using BBMS.Models;

namespace BBMS.Login
{
    public class LoginReponse
    {
        public string? Status { get; set; }
        public string? Msg { get; set; }
        public UserManagement _userManagement { get; set; } = new UserManagement();
    }
}
