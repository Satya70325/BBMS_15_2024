﻿namespace BBMS
{
    public static class Constants
    {
        public const string AdministratorRoleId = "1EA44CE7-667B-436A-982D-D419E74DE322";
        public const string StaffRoleId = "95117A42-6456-46A5-8ACB-0E0B0E0E8A96";
        public const string DonorRoleId = "AAC21712-38EA-4CF7-A1BE-ACC0AEAEF72C";
        public const string UserRoleId = "31C2282F-40E7-4A58-86FB-DCD73ADD4C01";
    }
}
