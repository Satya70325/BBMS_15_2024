﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BBMS.Data;
using BBMS.Models;
using BBMS.Constatnts;

namespace BBMS.Controllers
{
    public class BloodDonationsController : Controller
    {
        private readonly BBMSDataContext _context;

        public BloodDonationsController(BBMSDataContext context)
        {
            _context = context;
        }

        // GET: BloodDonations
        public async Task<IActionResult> Index()
        {
            if (UserProfile.RoleId == 1 || UserProfile.RoleId == 2 )
            {
                

                var bBMSDataContext = _context.BloodDonations.Where(s => !s.IsDeleted).Include(b => b.BloodGroupTypes).Include(b => b.UserManagements);
                return View(await bBMSDataContext.ToListAsync());
            }
            else
            {
                if (UserProfile.RoleId == 3)
                {
                    var bBMSDataContext = _context.BloodDonations.Where(s => !s.IsDeleted && s.UserManagementId == UserProfile.UserId).Include(b => b.BloodGroupTypes).Include(b => b.UserManagements);
                    return View(await bBMSDataContext.ToListAsync());
                }
                else
                {
                    return View(new List<BloodDonation>());
                }
            }
        }

        // GET: BloodDonations/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null || _context.BloodDonations == null)
            {
                return NotFound();
            }

            var bloodDonation = await _context.BloodDonations
                .Include(b => b.BloodGroupTypes)
                .Include(b => b.UserManagements)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bloodDonation == null)
            {
                return NotFound();
            }

            return View(bloodDonation);
        }

        // GET: BloodDonations/Create
        public IActionResult Create()
        {
            BloodDonation bloodDonations = new BloodDonation();
            bloodDonations.UserManagementId = UserProfile.UserId;

            ViewData["BloodGroupTypeId"] = new SelectList(_context.BloodGroupTypes.Where(s=>!s.IsDeleted), "Id", "GroupName");
            ViewData["UserManagementId"] = new SelectList(_context.UserManagements.Where(s => !s.IsDeleted), "Id", "FirstName");
            return View(bloodDonations);
        }

        // POST: BloodDonations/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UserManagementRowId,UserManagementId,BloodGroupTypeRowId,BloodGroupTypeId,DonationDate,IsDonarSubmitted,NumberofUnits,RBCCount,WBCCount,PlateletsCount,IsDonationDone,Id,RowId,CreatedBy,ModifiedBy,CreatedOn,ModifiedOn,IsDeleted,OrderBy")] BloodDonation bloodDonation)
        {
            if (ModelState.IsValid)
            {
                if (!string.IsNullOrEmpty(UserProfile.UserName))
                {
                    bloodDonation.CreatedBy = UserProfile.UserName;
                    bloodDonation.ModifiedBy = UserProfile.UserName;
                }
                else
                {
                    bloodDonation.CreatedBy = "Administrator";
                    bloodDonation.ModifiedBy = "Administrator";
                }

                var bgGrps = await _context.BloodGroupTypes.Where(s => s.Id == bloodDonation.BloodGroupTypeId).FirstOrDefaultAsync();
                bloodDonation.BloodGroupTypeRowId = bgGrps!.RowId;

                var UserGrps = await _context.UserManagements.Where(s => s.Id == bloodDonation.UserManagementId).FirstOrDefaultAsync();
                bloodDonation.UserManagementRowId = UserGrps!.RowId;

                bloodDonation.IsDonarSubmitted = true;

                _context.Add(bloodDonation);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["BloodGroupTypeId"] = new SelectList(_context.BloodGroupTypes.Where(s => !s.IsDeleted), "Id", "GroupName", bloodDonation.BloodGroupTypeId);
            ViewData["UserManagementId"] = new SelectList(_context.UserManagements.Where(s => !s.IsDeleted), "Id", "FirstName", bloodDonation.UserManagementId);
            return View(bloodDonation);
        }

        // GET: BloodDonations/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null || _context.BloodDonations == null)
            {
                return NotFound();
            }

            var bloodDonation = await _context.BloodDonations.FindAsync(id);
            if (bloodDonation == null)
            {
                return NotFound();
            }
            ViewData["BloodGroupTypeId"] = new SelectList(_context.BloodGroupTypes.Where(s => !s.IsDeleted), "Id", "GroupName", bloodDonation.BloodGroupTypeId);
            ViewData["UserManagementId"] = new SelectList(_context.UserManagements.Where(s => !s.IsDeleted), "Id", "FirstName", bloodDonation.UserManagementId);
            return View(bloodDonation);
        }

        // POST: BloodDonations/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long id, [Bind("UserManagementRowId,UserManagementId,BloodGroupTypeRowId,BloodGroupTypeId,DonationDate,IsDonarSubmitted,NumberofUnits,RBCCount,WBCCount,PlateletsCount,IsDonationDone,Id,RowId,CreatedBy,ModifiedBy,CreatedOn,ModifiedOn,IsDeleted,OrderBy")] BloodDonation bloodDonation)
        {
            if (id != bloodDonation.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (!string.IsNullOrEmpty(UserProfile.UserName))
                    {
                        bloodDonation.ModifiedOn = DateTime.Now;
                        bloodDonation.ModifiedBy = UserProfile.UserName;
                    }
                    else
                    {
                        bloodDonation.ModifiedOn = DateTime.Now;
                        bloodDonation.ModifiedBy = "Administrator";
                    }


                    var bgGrps = await _context.BloodGroupTypes.Where(s => s.Id == bloodDonation.BloodGroupTypeId).FirstOrDefaultAsync();
                    bloodDonation.BloodGroupTypeRowId = bgGrps!.RowId;

                    var UserGrps = await _context.UserManagements.Where(s => s.Id == bloodDonation.UserManagementId).FirstOrDefaultAsync();
                    bloodDonation.UserManagementRowId = UserGrps!.RowId;

                    bloodDonation.IsDonationDone = true;
                    _context.Update(bloodDonation);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BloodDonationExists(bloodDonation.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["BloodGroupTypeId"] = new SelectList(_context.BloodGroupTypes.Where(s => !s.IsDeleted), "Id", "GroupName", bloodDonation.BloodGroupTypeId);
            ViewData["UserManagementId"] = new SelectList(_context.UserManagements.Where(s => !s.IsDeleted), "Id", "FirstName", bloodDonation.UserManagementId);
            return View(bloodDonation);
        }

        // GET: BloodDonations/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null || _context.BloodDonations == null)
            {
                return NotFound();
            }

            var bloodDonation = await _context.BloodDonations
                .Include(b => b.BloodGroupTypes)
                .Include(b => b.UserManagements)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (bloodDonation == null)
            {
                return NotFound();
            }

            return View(bloodDonation);
        }

        // POST: BloodDonations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            if (_context.BloodDonations == null)
            {
                return Problem("Entity set 'BBMSDataContext.BloodDonations'  is null.");
            }
            var bloodDonation = await _context.BloodDonations.FindAsync(id);
            if (bloodDonation != null)
            {
                if (!string.IsNullOrEmpty(UserProfile.UserName))
                {
                    bloodDonation.ModifiedOn = DateTime.Now;
                    bloodDonation.ModifiedBy = UserProfile.UserName;
                }
                else
                {
                    bloodDonation.ModifiedOn = DateTime.Now;
                    bloodDonation.ModifiedBy = "Administrator";
                }
                bloodDonation.IsDeleted = true;
                _context.Update(bloodDonation);               
               // _context.BloodDonations.Remove(bloodDonation);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BloodDonationExists(long id)
        {
          return (_context.BloodDonations?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
