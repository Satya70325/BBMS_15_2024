﻿using BBMS.Constatnts;
using BBMS.Data;
using BBMS.Login;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BBMS.Controllers
{
    public class LoginController : Controller
    {
        private readonly BBMSDataContext _context;

        public LoginController(BBMSDataContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            LoginVM login = new LoginVM();
            ViewData["UserRoles"] = new SelectList(_context.UserRoles.Where(s => !s.IsDeleted), "Id", "RoleName");
            return View(login);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(LoginVM login)
        {
            if (ModelState.IsValid)
            {
                var User = await _context.UserManagements.Where(s => s.UserName == login.UserName && s.PassWord == login.Password && s.UserRoleId == login.RoleId).FirstOrDefaultAsync();
                if (User != null)
                {
                    var Userrole = await _context.UserRoles.Where(s => s.Id == login.RoleId).FirstOrDefaultAsync();
                   
                    UserProfile.UserName = login.UserName;
                    UserProfile.UserId = User.Id;
                    UserProfile.RoleId= login.RoleId;
                    UserProfile.Emailid = User.PrimaryEmail;
                    UserProfile.RoleName = Userrole!.RoleName;
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ViewBag.Message = "Invalid User";
                    ViewData["UserRoles"] = new SelectList(_context.UserRoles.Where(s => !s.IsDeleted), "Id", "RoleName");
                    return View(login);
                }
            }
            return View(login);
        }

        public IActionResult LogOut()
        {
            UserProfile.UserName = null;
            UserProfile.UserId = null;
            UserProfile.RoleId = null;
            UserProfile.Emailid = null;
            UserProfile.RoleName = null;
            return RedirectToAction(nameof(Index));
        }

    }
}
