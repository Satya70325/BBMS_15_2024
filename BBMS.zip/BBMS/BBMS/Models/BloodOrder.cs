﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BBMS.Models
{
    public class BloodOrder : BBMSBase
    {
       
        public string? UserManagementRowId { get; set; }
        public long? UserManagementId { get; set; }
        [ForeignKey("UserManagementId")]
        public UserManagement? UserManagements { get; set; }

       
        public string? BloodGroupTypeRowId { get; set; }
        public long? BloodGroupTypeId { get; set; }
        [ForeignKey("BloodGroupTypeId")]
        public BloodGroupType? BloodGroupTypes { get; set; }


        public long NoOfUnitsAvailable { get; set; }
        [Required]
        
        public long NoOfUnitsRequired { get; set; }

        public bool UserRequested { get; set; }
        public bool UserCancelled { get; set; }
        public bool PaymentRecieved { get; set; }
        public PaymentDetail? PaymentDetails { get; set; } = new PaymentDetail();


        public bool StaffProcessed { get; set; }
        public bool StaffCancelled { get; set; }
        public InventoryDetail? InventoryDetails { get; set; } = new InventoryDetail();



        public bool SampleOutFordelivery { get; set; }
        public OrdeDeliveryDetail? OrdeDeliveryDetails { get; set; } = new OrdeDeliveryDetail();
    }

    public class PaymentDetail : BBMSBase
    {
        public bool PaymentRecieved { get; set; }
        public bool PaymentCancelled { get; set; }
        public DateTime? PaymentDate { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        //[Required]
        public decimal? PaymentAmount { get; set; }
        public string? TransactionNumber { get; set; }
        public string? TransactionDetails { get; set; }
        public string? TransactionType { get; set; }
        public string? TransactionCardDetails { get; set; }


        public long BloodOrderId { get; set; }
        public BloodOrder? BloodOrder { get; set; }
    }
    public class InventoryDetail : BBMSBase
    {
        public string? InventoryNumber { get; set; }
        public DateTime? InventoryDate { get; set; }
        public long BloodOrderId { get; set; }
        public BloodOrder? BloodOrder { get; set; }
    }
    public class OrdeDeliveryDetail : BBMSBase
    {
        public bool OutFordelivery { get; set; }
        public DateTime? OutFordeliveryDate { get; set; }
        public string? DeliveryPersonDetails { get; set; }
        public bool delivered { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public string? DeliveryOTP { get; set; }
        public long BloodOrderId { get; set; }
        public BloodOrder? BloodOrder { get; set; }
    }
}
