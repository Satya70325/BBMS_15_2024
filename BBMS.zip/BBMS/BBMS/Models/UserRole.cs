﻿namespace BBMS.Models
{
    public class UserRole:BBMSBase
    {
        public string? RoleName { get; set; }
        public string? RoleId { get; set; }
    }
}
