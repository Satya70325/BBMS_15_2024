﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BBMS.Models
{
    public class UserManagement:BBMSBase
    {
        public string? UserRoleRowId { get; set; }
        public long? UserRoleId { get; set; }
        [ForeignKey("UserRoleId")]
        public UserRole? UserRoles { get; set; }

        [Required]
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        [Required]
        public string? LastName { get; set; }
        
        [Required]
        [RegularExpression(@"[6-9]\d{9}", ErrorMessage = "Mobile No. should start with 6, 7, 8, and 9 only and can be having a length of 10 digits.")]
         public long? PrimaryMobile { get; set; }
        
        [RegularExpression(@"[6-9]\d{9}", ErrorMessage = "Mobile No. should start with 6, 7, 8, and 9 only and can be having a length of 10 digits.")]
        public long? SecondaryMobile { get; set; }
        [Required]
        public string? PrimaryEmail { get; set; }
        public string? SecondaryEmail { get; set; }
        [Required]
        public string? Address1 { get; set; }
        [Required]
        public string? Address2 { get; set; }
        [Required]
        public string? Address3 { get; set; }
        public long PinCode { get; set; }

        [Required]
        public string? UserName { get; set; }
        [Required]
        public string? PassWord { get; set; }
    }
}
