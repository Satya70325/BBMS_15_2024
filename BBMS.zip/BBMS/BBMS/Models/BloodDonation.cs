﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BBMS.Models
{
    public class BloodDonation : BBMSBase
    {
       
        public string? UserManagementRowId { get; set; }
        public long? UserManagementId { get; set; }
        [ForeignKey("UserManagementId")]
        public UserManagement? UserManagements { get; set; }

        
        public string? BloodGroupTypeRowId { get; set; }
        public long? BloodGroupTypeId { get; set; }
        [ForeignKey("BloodGroupTypeId")]
        public BloodGroupType? BloodGroupTypes { get; set; }


        [Required]
        public DateTime? DonationDate { get; set; }
        public bool IsDonarSubmitted { get; set; }


        public long NumberofUnits { get; set; }
        public long RBCCount { get; set; }
        public long WBCCount { get; set; }
        public long PlateletsCount { get; set; }
        public bool IsDonationDone { get; set; }
    }
}
